package com.example.smdproject;

import android.view.View;

public interface catClickListner {
    public void oncatItemClick(View v, int position);
}
