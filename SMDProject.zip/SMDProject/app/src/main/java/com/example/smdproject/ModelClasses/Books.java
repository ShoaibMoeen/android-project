package com.example.smdproject.ModelClasses;

import android.net.Uri;

import java.util.UUID;

public class Books {

    private String name;
    private String bookId;
    private String authorId;
    private String categorie;
    private String imageUrl;
    private String description;
    private String price;

    public Books()
    {

    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getCategorie() {
        return categorie;
    }

    public String getPrice() {
        return price;
    }

    public Books(String n, String d, String C, String url, String id, String aid, String p)
    {
        name=n;
        description=d;
        categorie=C;
        bookId=id;
        authorId=aid;
        imageUrl=url;
        price=p;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBookId() {
        return bookId;
    }

    public String getAuthorId() {
        return authorId;
    }

    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
