package com.example.smdproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.smdproject.ModelClasses.Books;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Text;

import java.util.List;

public class BookVIew extends AppCompatActivity {
    Books b;
    FirebaseFirestore db;
    CollectionReference cf;
    StorageReference fs;
    ImageView i;
    TextView n1,d1,p1;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_view);
        String bid=getIntent().getStringExtra("currbookId");
        i=findViewById(R.id.bookviewimg);
        n1=findViewById(R.id.bookviewName);
        d1=findViewById(R.id.bookviewdesc);
        p1=findViewById(R.id.bookviewPrice);
        db= FirebaseFirestore.getInstance();
        cf=db.collection("Books");
        cf.whereEqualTo("bookId",bid).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty())
                {
                    List<DocumentSnapshot> ds=queryDocumentSnapshots.getDocuments();
                    for(DocumentSnapshot d:ds)
                    {
                        String n=d.getString("name");
                        String aid=d.getString("authorId");
                        String bid=d.getString("bookId");
                        String c=d.getString("Categorie");
                        String des=d.getString("description");
                        String img=d.getString("imageUrl");
                        String p=d.getString("price");
                        b=new Books(n,des,c,img,bid,aid,p);
                        n1.setText(b.getName());
                        d1.setText(b.getDescription());
                        p1.setText(b.getPrice());
                        downloadimg(b.getImageUrl());

                    }



                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

    }

    public void downloadimg(String uri)
    {
        if(uri!=null) {
            fs = FirebaseStorage.getInstance().getReference();
            StorageReference imgref = fs.child("Images/"+uri);

            final long ONE_MEGABYTE = 1024 * 1024;
            imgref.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    Bitmap b= BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    i.setImageBitmap(b);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    // Handle any errors
                }
            });
        }
    }
}
