package com.example.smdproject.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.smdproject.ModelClasses.Books;
import com.example.smdproject.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class ProfileFragment extends Fragment {
    FirebaseFirestore db;
    CollectionReference cf;
    FirebaseUser users;
    TextView t1,t2,t3;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_profile, container, false);
        users=FirebaseAuth.getInstance().getCurrentUser();
        t1=root.findViewById(R.id.profileName);
        t2=root.findViewById(R.id.profileEmail);
        t3=root.findViewById(R.id.profilePhone);
        String uid=users.getUid();
        db= FirebaseFirestore.getInstance();
        cf=db.collection("Users");
        cf.whereEqualTo("userId",uid).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty())
                {
                    List<DocumentSnapshot> ds=queryDocumentSnapshots.getDocuments();
                    for(DocumentSnapshot d:ds)
                    {
                        String n=d.getString("uname");
                        String e=d.getString("uEmail");
                        t1.setText(n);
                        t2.setText(e);
                        t3.setText("Not Available");

                    }
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

        return root;
    }
}