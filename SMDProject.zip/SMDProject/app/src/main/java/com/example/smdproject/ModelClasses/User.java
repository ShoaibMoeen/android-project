package com.example.smdproject.ModelClasses;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class User {

    private String uname;
    private String uEmail;
    private String Id;
    private String password;
    private List<String> userBooks;
    private String type;
    public User() {
    }

    public String getType() {
        return type;
    }

    public String getUserId() {
        return Id;
    }

    public User(String uname, String uEmail, String password,String uid,String t) {

        this.uname = uname;
        this.uEmail = uEmail;
        this.password = password;
        type=t;
        userBooks=new ArrayList<>();
        Id=uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getuEmail() {
        return uEmail;
    }

    public void setuEmail(String uEmail) {
        this.uEmail = uEmail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
