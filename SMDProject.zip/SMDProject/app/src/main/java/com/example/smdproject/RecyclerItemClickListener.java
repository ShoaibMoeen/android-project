package com.example.smdproject;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public interface RecyclerItemClickListener
{
    public void onItemClick(View v,int position);
}