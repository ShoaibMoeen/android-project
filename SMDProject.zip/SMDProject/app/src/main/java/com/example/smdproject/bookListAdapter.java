package com.example.smdproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smdproject.ModelClasses.Books;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.List;

public class bookListAdapter extends
        RecyclerView.Adapter<bookListAdapter.ViewHolder> {
    private RecyclerItemClickListener mlisten;
    private List<Books> mBooks;
    private Context mcontext;
    StorageReference fs,ref;
    // Provide a direct reference to each of the views within a data item
    // Used to cache the views within the item layout for fast access
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        public TextView nameTextView;
        public Button messageButton;
        public ImageView img;
        RecyclerItemClickListener rl;

        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        public ViewHolder(View itemView,RecyclerItemClickListener l) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance.
            super(itemView);
            rl=l;
            img=(ImageView) itemView.findViewById(R.id.bookitemimg);
            nameTextView = (TextView) itemView.findViewById(R.id.listitemname);
            messageButton = (Button) itemView.findViewById(R.id.buylistitembtn);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            rl.onItemClick(v,getAdapterPosition());
        }
    }

    // Pass in the contact array into the constructor
    public bookListAdapter(List<Books> books,RecyclerItemClickListener l) {
        mBooks = books;
        mlisten=l;
    }
    @Override
    public bookListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View bookView = inflater.inflate(R.layout.booklistitem, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(bookView,mlisten);
        return viewHolder;
    }

    // Involves populating data into the item through holder
    @Override
    public void onBindViewHolder(bookListAdapter.ViewHolder viewHolder, int position)
    {
        // Get the data model based on position
        String bookname = mBooks.get(position).getName();
        // Set item views based on your views and data model
        TextView textView = viewHolder.nameTextView;
        textView.setText(bookname);
        Button button = viewHolder.messageButton;
        button.setText(mBooks.get(position).getPrice());
        ImageView i=viewHolder.img;
        downloadImg(mBooks.get(position).getImageUrl(),viewHolder);
    }

    // Returns the total count of items in the list
    @Override
    public int getItemCount() {
        return mBooks.size();
    }
    public void downloadImg(String uri, final ViewHolder viewHolder)
    {
        if(uri!=null) {
            fs = FirebaseStorage.getInstance().getReference();
            StorageReference imgref = fs.child("Images/"+uri);

            final long ONE_MEGABYTE = 1024 * 1024;
            imgref.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    ImageView i=viewHolder.img;
                    Bitmap b= BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    i.setImageBitmap(b);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    // Handle any errors
                }
            });
        }
    }
}