package com.example.smdproject.ui.published;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.smdproject.AddNewBook;
import com.example.smdproject.ModelClasses.Books;
import com.example.smdproject.R;
import com.example.smdproject.RecyclerItemClickListener;
import com.example.smdproject.featuredlistadapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;


public class PublishedBooksFragment extends Fragment implements RecyclerItemClickListener {



    private OnFragmentInteractionListener mListener;

    public PublishedBooksFragment() {
        // Required empty public constructor
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        final View root = inflater.inflate(R.layout.fragment_published_books, container, false);

        FloatingActionButton fab = root.findViewById(R.id.floating_action_button);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), AddNewBook.class));
            }
        });
        RecyclerView f=(RecyclerView) root.findViewById(R.id.mypublishedBooksitems);
        List<Books> b =new ArrayList<Books>();
        for(int i=1;i<=5;i++)
        {
           // Books bk=new Books("Book"+i,"author"+i,"Book"+i+"Description");
          //  b.add(bk);
        }
        featuredlistadapter t=new featuredlistadapter(getContext(),b,this);
        f.setAdapter(t);
        return root;
    }

    public void onItemClick(View v, int position) {
        Toast.makeText(getContext(),"Position clicked" +position,Toast.LENGTH_LONG).show();
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
