package com.example.smdproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.smdproject.ModelClasses.Books;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class CategoryView extends AppCompatActivity implements RecyclerItemClickListener{
    private AppBarConfiguration mAppBarConfiguration;

    List<Books> blist=new ArrayList<>();
    FirebaseFirestore db;
    CollectionReference cf;
    featuredlistadapter fa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_view);
        String cat=getIntent().getStringExtra("catName");
        Toolbar toolbar = findViewById(R.id.authortoolbar);
        setSupportActionBar(toolbar);

        fa=new featuredlistadapter(this,blist,this);
        RecyclerView f=(RecyclerView) findViewById(R.id.catviewlist);
        db= FirebaseFirestore.getInstance();
        cf=db.collection("Books");

        cf.whereEqualTo("categorie",cat).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty())
                {
                    List<DocumentSnapshot> ds=queryDocumentSnapshots.getDocuments();
                    for(DocumentSnapshot d:ds)
                    {
                        String n=d.getString("name");
                        String aid=d.getString("authorId");
                        String bid=d.getString("bookId");
                        String c=d.getString("Categorie");
                        String des=d.getString("description");
                        String img=d.getString("imageUrl");
                        String p=d.getString("price");
                        Books b=new Books(n,des,c,img,bid,aid,p);
                        blist.add(b);

                    }

                    fa.notifyDataSetChanged();

                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
        f.setAdapter(fa);

    }

    @Override
    public void onItemClick(View v, int position) {
        Intent i=new Intent(getApplicationContext(),BookVIew.class);
        i.putExtra("currbookId",blist.get(position).getBookId());
        startActivity(i);
    }
}
