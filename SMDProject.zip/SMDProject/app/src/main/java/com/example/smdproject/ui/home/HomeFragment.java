package com.example.smdproject.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.smdproject.*;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smdproject.ModelClasses.Books;
import com.example.smdproject.ModelClasses.Category;
import com.example.smdproject.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomeFragment extends Fragment implements  RecyclerItemClickListener,catClickListner{

    private HomeViewModel homeViewModel;
    StorageReference fs;
    FirebaseFirestore db;
    Uri mImageUri;
    StorageTask st; CollectionReference cf;
    FirebaseAuth f;
    List<Books> blist=new ArrayList<>();
    List<Category> clist=new ArrayList<>();
    bookListAdapter bookAdapter;
    categoriesListAdapter ca;
    featuredlistadapter fa;
    public HomeFragment()
    {
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        //homeViewModel =
         //       ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        ca=new categoriesListAdapter(clist,this);
        fa=new featuredlistadapter(getContext(),blist,this);
        bookAdapter=new bookListAdapter(blist,this);
        db=FirebaseFirestore.getInstance();
        cf=db.collection("Books");
        cf.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty())
                {
                    List<DocumentSnapshot> ds=queryDocumentSnapshots.getDocuments();
                    for(DocumentSnapshot d:ds)
                    {
                        String n=d.getString("name");
                        String aid=d.getString("authorId");
                        String bid=d.getString("bookId");
                        String c=d.getString("Categorie");
                        String des=d.getString("description");
                        String img=d.getString("imageUrl");
                        String p=d.getString("price");
                        Books b=new Books(n,des,c,img,bid,aid,p);
                        blist.add(b);

                    }
                    ca.notifyDataSetChanged();
                    fa.notifyDataSetChanged();
                    bookAdapter.notifyDataSetChanged();
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

        cf=db.collection("Categories");
        cf.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty())
                {
                    List<DocumentSnapshot> ds=queryDocumentSnapshots.getDocuments();
                    for(DocumentSnapshot d:ds)
                    {
                        String n=d.getString("name");
                        String img=d.getString("imgId");
                        Category c=new Category(n,img);
                        clist.add(c);

                    }
                    ca.notifyDataSetChanged();
                    fa.notifyDataSetChanged();
                    bookAdapter.notifyDataSetChanged();
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
        RecyclerView r=(RecyclerView) root.findViewById(R.id.bookitems);
        List<Books> b =new ArrayList<Books>();
        for(int i=1;i<=5;i++)
        {
            //Books bk=new Books("Book"+i,"author"+i,"Book"+i+"Description");
            //b.add(bk);
        }

        r.setAdapter(bookAdapter);
        RecyclerView c=(RecyclerView) root.findViewById(R.id.categoriesitems);

        c.setAdapter(ca);
        RecyclerView f=(RecyclerView) root.findViewById(R.id.featuredlist);

        f.setAdapter(fa);
        

        return root;
    }

    @Override
    public void onItemClick(View v, int position) {
        Toast.makeText(getContext(),"Position clicked " + position,Toast.LENGTH_LONG).show();

    }

    @Override
    public void oncatItemClick(View v, int position) {
        Intent i=new Intent(getContext(),CategoryView.class);
        i.putExtra("catName",clist.get(position).getName());
        startActivity(i);
    }
}