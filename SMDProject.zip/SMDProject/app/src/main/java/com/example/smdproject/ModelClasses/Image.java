package com.example.smdproject.ModelClasses;

public class Image {
    private String Id;
    private String mImageUrl;



    public Image()
    {}
    public Image(String id,String url) {
        Id = id;
        mImageUrl=url;
    }

    public String getId() {
        return Id;
    }

    public String getmImageUrl() {
        return mImageUrl;
    }
}
