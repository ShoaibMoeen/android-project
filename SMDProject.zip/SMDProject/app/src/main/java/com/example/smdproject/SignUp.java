package com.example.smdproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


import com.example.smdproject.ModelClasses.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

public class SignUp extends AppCompatActivity {
    EditText un,em,pass,cpass;
    Button b;
    RadioGroup type;
    RadioButton selectedType;
    TextView l;
    String u=null,e=null,p=null,c=null;
    FirebaseAuth mAuth;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        un=findViewById(R.id.signupfullname);
        em=findViewById(R.id.usersignupemail);
        pass=findViewById(R.id.usersignuppass);
        cpass=findViewById(R.id.usercfmpass);
        b=findViewById(R.id.usersignupbtn);
        type=findViewById(R.id.signupType);
        l=findViewById(R.id.loginBtnOnSignup);
        mAuth=FirebaseAuth.getInstance();
        db=FirebaseFirestore.getInstance();
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                u=un.getText().toString();
                e=em.getText().toString();
                p=pass.getText().toString();
                c=cpass.getText().toString();
                final int i=type.getCheckedRadioButtonId();


                if(TextUtils.isEmpty(u))
                {
                    Toast.makeText(SignUp.this,"Please Enter Name",Toast.LENGTH_LONG).show();
                    return;
                }
                if(TextUtils.isEmpty(e))
                {
                    Toast.makeText(SignUp.this,"Please Enter Email",Toast.LENGTH_LONG).show();
                    return;
                }
                if(TextUtils.isEmpty(p))
                {
                    Toast.makeText(SignUp.this,"Please Enter password",Toast.LENGTH_LONG).show();
                    return;
                }
                if(p.length()<6)
                {
                    Toast.makeText(SignUp.this,"Password too short",Toast.LENGTH_LONG).show();
                    return;
                }
                if(!p.equals(c))
                {
                    Toast.makeText(SignUp.this,"Password and Confirm Password dont match",Toast.LENGTH_LONG).show();
                    return;
                }
                if(i==-1)
                {
                    Toast.makeText(SignUp.this,"Please Select User Type",Toast.LENGTH_LONG).show();
                    return;
                }
                if(p.equals(c))
                {
                    mAuth.createUserWithEmailAndPassword(e, p)
                            .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Sign in success, update UI with the signed-in user's information
                                        FirebaseUser user = mAuth.getCurrentUser();

                                        if(i==R.id.typeUser)
                                        {

                                            User us=new User(u,e,p,user.getUid(),"User");
                                            db.collection("Users").document(us.getUserId()).set(us);
                                            startActivity(new Intent(getApplicationContext(),UserHome.class));
                                        }
                                        else if(i==R.id.typeAuthor)
                                        {
                                            User us=new User(u,e,p,user.getUid(),"Author");
                                            db.collection("Users").document(us.getUserId()).set(us);
                                            startActivity(new Intent(getApplicationContext(),AuthorHome.class));
                                        }

                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Toast.makeText(SignUp.this, "Authentication failed.",
                                                Toast.LENGTH_SHORT).show();
                                    }

                                    // ...
                                }
                            });

                }
            }
        });
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });
    }
}
