package com.example.smdproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smdproject.ModelClasses.Books;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class featuredlistadapter extends
        RecyclerView.Adapter<featuredlistadapter.ViewHolder>{
    private RecyclerItemClickListener mlisten;
    private List<Books> mBooks;
    private Context mcontext;
    StorageReference fs,ref;


    // Provide a direct reference to each of the views within a data item
    // Used to cache the views within the item layout for fast access
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        // Your holder should contain a member variable
        // for any view that will be set as you render a row

        public TextView nameTextView;
        public TextView description;
        public ImageView img;
        public RecyclerItemClickListener ml;


        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        public ViewHolder(View itemView,RecyclerItemClickListener l) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance.
            super(itemView);
            ml=l;
            img=(ImageView) itemView.findViewById(R.id.flistitemimg);
            nameTextView = (TextView) itemView.findViewById(R.id.flistitemname);
            description = (TextView) itemView.findViewById(R.id.flistitemdesc);
            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {
            if(mlisten!=null)
                ml.onItemClick(v,getAdapterPosition());
        }
    }
    // Pass in the contact array into the constructor
    public featuredlistadapter(Context c,List<Books> books,RecyclerItemClickListener l) {
        mBooks = books;
        mcontext=c;
        mlisten=l;
    }
    @Override
    public featuredlistadapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View bookView = inflater.inflate(R.layout.featuredlistitem, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(bookView,mlisten);
        return viewHolder;
    }

    // Involves populating data into the item through holder
    @Override
    public void onBindViewHolder(featuredlistadapter.ViewHolder viewHolder, int position)
    {
        // Get the data model based on position
        String booksname = mBooks.get(position).getName();
        String d=mBooks.get(position).getDescription();
        // Set item views based on your views and data model
        TextView textView = viewHolder.nameTextView;
        textView.setText(booksname);
        TextView desc=viewHolder.description;
        desc.setText(d);

        downloadImg(mBooks.get(position).getImageUrl(),viewHolder);


    }

    // Returns the total count of items in the list
    @Override
    public int getItemCount() {
        return mBooks.size();
    }
    public void downloadImg(String uri, final ViewHolder viewHolder)
    {
        if(uri!=null) {
            fs = FirebaseStorage.getInstance().getReference();
            StorageReference imgref = fs.child("Images/"+uri);

            final long ONE_MEGABYTE = 1024 * 1024;
            imgref.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    ImageView i=viewHolder.img;
                    Bitmap b= BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    i.setImageBitmap(b);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    // Handle any errors
                }
            });
        }
    }
}