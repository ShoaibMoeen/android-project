package com.example.smdproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.smdproject.ModelClasses.Books;

import java.util.List;

public class testadapter extends ArrayAdapter<Books> {

    private Context mContext;
    private List<Books> mBooks;

    public testadapter(@NonNull Context context, List<Books> clist) {
        super(context, 0 , clist);
        mContext = context;
        mBooks = clist;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.featuredlistitem,parent,false);

        Books c = mBooks.get(position);


        TextView name = (TextView) listItem.findViewById(R.id.flistitemname);
        name.setText(c.getName());
        TextView d = (TextView) listItem.findViewById(R.id.flistitemdesc);
        name.setText(c.getDescription());


        return listItem;
    }
}