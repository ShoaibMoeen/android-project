package com.example.smdproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smdproject.ModelClasses.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText em,pa;
    String email,password;
    FirebaseAuth mAuth;
    FirebaseFirestore db;
    String t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b=(Button)findViewById(R.id.userloginbutton);
        mAuth=FirebaseAuth.getInstance();
        em=findViewById(R.id.uname);
        pa=findViewById(R.id.pass);
        //startActivity(new Intent(this, AuthorHome.class));
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email=em.getText().toString();
                password=pa.getText().toString();
                if(TextUtils.isEmpty(email))
                {
                    Toast.makeText(MainActivity.this,"Please Enter Email",Toast.LENGTH_LONG).show();
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    Toast.makeText(MainActivity.this,"Please Enter Password",Toast.LENGTH_LONG).show();
                    return;
                }
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    db=FirebaseFirestore.getInstance();
                                    DocumentReference cf=db.collection("Users").document(user.getUid());
                                    cf.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                        @Override
                                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                                            String t=documentSnapshot.getString("type");
                                            if(t.equals("User"))
                                            {
                                                Intent i=new Intent(getApplicationContext(),UserHome.class);

                                                startActivity(i);
                                            }
                                            else if(t.equals("Author"))
                                            {
                                                Intent i=new Intent(getApplicationContext(),AuthorHome.class);

                                                startActivity(i);
                                            }
                                        }
                                    });
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(MainActivity.this, "Invalid Email or Password.",
                                            Toast.LENGTH_SHORT).show();
                                }


                            }
                        });
            }
        });
        TextView signup =(TextView) findViewById(R.id.signupbtnonlogin);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signupintent=new Intent(getApplicationContext(),SignUp.class);
                startActivity(signupintent);
            }
        });
    }
}
